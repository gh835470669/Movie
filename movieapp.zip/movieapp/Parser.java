package com.example.zhangwei.movieapp;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.List;

/**
 * Created by zhangwei on 2017/6/16.
 */

public class Parser {
    public Parser () {}
    public void parseMovies(String json, List<movieItem> movieItemList) {
        if (json == null) return;
        try {
            JSONObject object = new JSONObject(json);
            JSONObject object1 = object.optJSONObject("data");
            JSONArray array = object1.optJSONArray("movies");
            for (int i = 0; i < array.length(); ++i) {
                JSONObject object2 = array.getJSONObject(i);
                String showInfo = object2.optString("showInfo");
                String img = object2.optString("img");
                String nm = object2.optString("nm");
                String cat = object2.optString("cat");
                String star = object2.optString("star");
                String date = object2.getString("rt");
                String dir = object2.getString("dir");
                boolean imax = object2.optBoolean("imax");
                boolean _3d = object2.optBoolean("3d");

                int id = object2.optInt("id");
                double score = object2.optDouble("sc");
                movieItem movieitem = new movieItem(id, nm, img, ""+score, date, dir,star, cat);
                movieItemList.add(movieitem);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void parseTheatres(String json,List<theatreItem> theatreItemList) {
        if (json == null) return;

        try {
            JSONObject object = new JSONObject(json);
            JSONObject object1 = object.optJSONObject("data");
            Iterator<String> iterator =  object1.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                JSONArray array = object1.optJSONArray(key);
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object2 = array.getJSONObject(i);
                    String nm = object2.optString("nm");
                    String addr = object2.optString("addr");
                    String area = object2.optString("area");
                    int id = object2.optInt("id");
                    double sellPrice = object2.optDouble("sellPrice");

                    theatreItemList.add(new theatreItem(id, nm, area, addr));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void parseComments(String json, int Id, List<movieItem> movieItemList) {
        if (json == null) return;

        try {
            JSONObject object = new JSONObject(json);
            JSONObject object1 = object.optJSONObject("data");
            JSONObject object3 = object1.optJSONObject("CommentResponseModel");
            //Log.d("...",object3.toString());
            JSONArray array = object3.optJSONArray("cmts");
            for (movieItem movieitem:movieItemList
                    ) {
                if (Id == movieitem.getMovieId()) {
                    for (int i = 0; i < array.length(); ++i) {
                        JSONObject object2 = array.getJSONObject(i);
                        String nick = object2.optString("nick");
                        String img = object2.optString("avatarurl");
                        String score = object2.optString("score");
                        String content = object2.optString("content");
                        String date = object2.optString("time");
                        //Log.d("output", nick + img + score + content + date);
                        commentItem commentitem = new commentItem(nick, img, score, content, date);
                        movieitem.setCommentItem(commentitem);
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
