package com.example.zhangwei.movieapp;

/**
 * Created by zhangwei on 2017/6/17.
 */

public class commentItem {
    public  commentItem() {}
    public commentItem(String userName1, String userImg1, String score1, String content1, String commentDate1) {
        userName = userName1;
        userImg = userImg1;
        score = score1;
        content = content1;
        commentDate = commentDate1;
    }
    private String userName; //用户名
    private String userImg; //用户头像
    private String score; //评分
    private String content; //内容
    private String commentDate; //日期

    public String getCommentDate() {
        return commentDate;
    }

    public String getContent() {
        return content;
    }

    public String getScore() {
        return score;
    }

    public String getUserImg() {
        return userImg;
    }

    public String getUserName() {
        return userName;
    }
}
