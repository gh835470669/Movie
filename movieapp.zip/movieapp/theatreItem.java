package com.example.zhangwei.movieapp;

/**
 * Created by zhangwei on 2017/6/17.
 */

public class theatreItem {
    public theatreItem(int theatreId1,  String theatreName1, String theatreArea1, String theatreAddr1) {
        theatreId = theatreId1;
        theatreArea = theatreArea1;
        theatreName = theatreName1;
        theatreAddr = theatreAddr1;
    }
    public int getTheatreId() {
        return theatreId;
    }

    public String getTheatreAddr() {
        return theatreAddr;
    }

    public String getTheatreArea() {
        return theatreArea;
    }

    public String getTheatreName() {
        return theatreName;
    }
    private int theatreId;
    private String theatreArea;
    private String theatreName;
    private String theatreAddr;
}
