package com.example.zhangwei.movieapp;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangwei on 2017/6/15.
 */

public class movieItem {
    public movieItem() {
        super();
    }

    public movieItem(int movieId1, String movieName1, String imgPath1, String userRating1, String releaseDate1, String dir1, String star1, String type1) {
        movieId = movieId1;
        movieName = movieName1;
        imgPath = imgPath1;
        userRating = userRating1;
        releaseDate = releaseDate1;
        dir = dir1;
        star = star1;
        type = type1;
        commentItemList  = new ArrayList<commentItem>();
    }
    private  int movieId;//电影id
    private  String movieName; //电影名称
    private  String imgPath; //图片路径
    private  String  userRating; //用户评分
    private  String  releaseDate; //上映日期
    private  String  dir; //导演
    private  String  star; //演员
    private  String  type; //类型
    private List<commentItem> commentItemList; //多条评论保存为一个List

    public int getMovieId() {
        return movieId;
    }
    public String getMovieName() {
        return  movieName;
    }

    public String getImgPath() {
        return imgPath;
    }

    public String getUserRating() {
        return  userRating;
    }
    public String getReleaseDate() {
        return releaseDate;
    }
    public String getDir() {
        return dir;
    }

    public String getStar() {
        return star;
    }

    public String getType() {
        return type;
    }
    //获取整个评论List
    public List<commentItem> getCommentItemList() {
        return commentItemList;
    }

    public void setCommentItem(commentItem commentItem1) {
        commentItemList.add(commentItem1);
    }

    public void setMovie(int movieId1, String movieName1, String imgPath1, String userRating1, String releaseDate1, String dir1, String star1, String type1) {
        movieId = movieId1;
        movieName = movieName1;
        imgPath = imgPath1;
        userRating = userRating1;
        releaseDate = releaseDate1;
        dir = dir1;
        star = star1;
        type = type1;
    }
}
