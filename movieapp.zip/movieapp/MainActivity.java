package com.example.zhangwei.movieapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private  String PATH;
    private TextView tv;
    private List<movieItem> movieItemList = new ArrayList<>();
    private List<theatreItem> theatreItemList = new ArrayList<>();
    private Parser parser = new Parser();
    private int choice = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.tv);
        getMovies();
        getTheatraas();
        try {
            Thread.sleep(3000L);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        getComments();
    }

    public void getMovies() {
        choice = 1;
        PATH = "http://m.maoyan.com/movie/list.json?type=hot&offset=0&limit=1000";
        getJSON(PATH, choice, 0);
    }

    public void getTheatraas() {
        choice = 2;
        PATH = "http://m.maoyan.com/cinemas.json";
        getJSON(PATH, choice, 0);
    }
    public void getComments() {
        choice = 3;
        Log.d("moviesSize", movieItemList.size()+"");
        for (movieItem movieitem: movieItemList
             ) {
            PATH = "http://m.maoyan.com/movie/"+ movieitem.getMovieId()+ ".json";
            //PATH = "http://m.maoyan.com/movie/248645.json";
           getJSON(PATH, choice, movieitem.getMovieId());
        }

    }

    public void getJSON(final String url, final int flag, final int movieId) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setRequestProperty("Accept-Charset", "utf-8");
                    conn.setRequestProperty("contentType", "utf-8");
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    int code = conn.getResponseCode();
                    if (code == 200) {
                        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        StringBuffer buffer = new StringBuffer();
                        String line = "";
                        while ((line = in.readLine()) != null) {
                            buffer.append(line);
                        }
                        String str = buffer.toString();
                        if (flag == 1) {
                            parser.parseMovies(str, movieItemList);
                        } else if (flag == 2) {
                            parser.parseTheatres(str, theatreItemList);
                        } else if (flag == 3) {
                            parser.parseComments(str, movieId, movieItemList);
                        }

                    } else {
                        Log.d("internet return", code+"");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }



    //显示结果
    public void click(View v){
        try {
            Message msg = new Message();
            String result = "";
            result = "";
            //电影信息
            for(movieItem item : movieItemList) {
                result = result + item.getMovieId() + " " + item.getMovieName() + " " + item.getImgPath()  + " "
                        + item.getUserRating() + " " + item.getReleaseDate()  + " " + item.getDir() + " "  + item.getStar() + " "  + item.getType() + "\n";
                List<commentItem> commentItemList = item.getCommentItemList();
                //每部电影评论
                for (commentItem commentitem:commentItemList
                     ) {
                    result = result + commentitem.getUserName() + " " + commentitem.getUserImg() + " " +  commentitem.getScore() + " " + commentitem.getContent() + " " + commentitem.getCommentDate() + "\n";
                }
            }
            //影院信息
            for(theatreItem item : theatreItemList) {
                result = result + item.getTheatreId() + " " + item.getTheatreName() + " " + item.getTheatreArea()  + " "
                        + item.getTheatreAddr() + "\n";
            }
            msg.obj = result;
            handler.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            tv.setText(msg.obj+"");
        }
    };
}

